﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class displayContent : MonoBehaviour {
    public string text;


    void Update()
    {
        GetComponent<TextMesh>().text = "aha";
    }


}
