﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class interact : MonoBehaviour {
    public static Vector3 mousePosition;

    public Mesh mesh;
    public Material material;
   


    void Start()
    { 
          GameObject  dataPoint = GameObject.CreatePrimitive(PrimitiveType.Sphere);
          dataPoint.transform.position = new Vector3(0F,0F,0F);
          dataPoint.GetComponent<MeshFilter>().mesh = mesh;
          dataPoint.GetComponent<MeshRenderer>().material = material;

        GameObject dataPoint1 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        dataPoint1.transform.position = new Vector3(1F, 1F, 1F);
        dataPoint1.GetComponent<MeshFilter>().mesh = mesh;
        dataPoint1.GetComponent<MeshRenderer>().material = material;
    }

    void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray))
                Destroy(this.gameObject);
        }

        Debug.Log(mousePosition);
    }
}
