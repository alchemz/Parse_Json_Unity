﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LitJson;
using System.IO;
using System;
using UnityEngine.UI;

public class readJson : MonoBehaviour {

    private string jsonString;
    private JsonData itemData;

    public Mesh mesh;
    public Material material;
    public GameObject dataPoint;
    public Text titleT;
    public Text authorT;
    public Text summaryT;
    public Text linkT;

    public GameObject canvas;


    void Start()
    {
        jsonString = File.ReadAllText(Application.dataPath + "/Resources/all.json");
        itemData = JsonMapper.ToObject(jsonString);
       

        for (int i = 0; i < itemData.Count; i++)
        {
            dataPoint = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            dataPoint.transform.position = new Vector3((float)(double)itemData[i]["coordinates"][0], (float)(double)itemData[i]["coordinates"][1], (float)(double)itemData[i]["coordinates"][2]);
            dataPoint.GetComponent<MeshFilter>().mesh = mesh;
            dataPoint.GetComponent<MeshRenderer>().material = material;
            dataPoint.transform.localScale = new Vector3(0.015F, 0.015F, 0.015F);

          
           titleT.text =(string) itemData[i]["title"];
           // authorT.text = (string)itemData[i]["author"][0];
            summaryT.text = (string)itemData[i]["summary"];
            linkT.text = (string)itemData[i]["id"];
            //Debug.Log((double)itemData[i]["coordinates"][0]+"   "+ (double)itemData[i]["coordinates"][1]+"    "+ (double)itemData[i]["coordinates"][2]);
           

            GameObject canvas_ = Instantiate(canvas, new Vector3(0, 0, 0), Quaternion.identity) as GameObject;
            canvas_.transform.position = dataPoint.transform.position;
           // enemy.transform.SetParent(GameObject.FindGameObjectWithTag("UI").transform, false);
        }       
      
    }

 
}
