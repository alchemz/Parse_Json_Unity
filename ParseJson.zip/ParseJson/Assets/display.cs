﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class display : MonoBehaviour {
    public Mesh mesh;
    public Material material;
    public TextMesh text;
    public GameObject dataPoint, dataPoint1;

    // Use this for initialization
    void Start () {
        dataPoint= GameObject.CreatePrimitive(PrimitiveType.Sphere);
        dataPoint.transform.position = new Vector3(1F, 2F, 4F);
        dataPoint.GetComponent<MeshFilter>().mesh = mesh;
        dataPoint.GetComponent<MeshRenderer>().material = material;

        dataPoint1 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        dataPoint1.transform.position = new Vector3(4F, 5F, 6F);
        dataPoint1.GetComponent<MeshFilter>().mesh = mesh;
        dataPoint1.GetComponent<MeshRenderer>().material = material;
    }

// Update is called once per frame
void Update () {
        if (Input.GetMouseButtonDown(0))
        { 
            text.transform.position = dataPoint.transform.position;
            text.GetComponent<TextMesh>().text = "ahahh";
        }
        if (Input.GetMouseButtonDown(1))
        { 
            text.transform.position = dataPoint1.transform.position;
            text.GetComponent<TextMesh>().text = "Yohu";
        }
    }
}
